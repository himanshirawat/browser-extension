export { images } from "./images";
export { quotes } from "./quotes";